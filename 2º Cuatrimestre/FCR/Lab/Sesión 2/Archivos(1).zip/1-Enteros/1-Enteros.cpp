#include <iostream>
using namespace std;

int main()
{
	unsigned int a = 23;
	int b = -5;

	cout << "a: " << a << " b: " << b << endl;

	if (a < b)
	{
		cout << "a es menor que b" << endl;
	}

	return 0;
}
