#include <iostream>

extern "C" bool IsValidAssembly(int a, int b, int c);

int main()
{

	return 0;
}
