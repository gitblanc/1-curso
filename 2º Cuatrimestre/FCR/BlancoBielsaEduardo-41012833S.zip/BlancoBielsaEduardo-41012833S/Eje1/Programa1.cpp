#include <iostream>

using namespace std;

int main()
{

	int a;
	unsigned int b;
	int c;
    int d;
	int e;
	unsigned int f;
	
	float g = 5.4;
	float h = -5.4;
	float i = 4.9;
	float j = -4.9;
	float k = -3.6;
	float l = 3.6;

	char cadena[] = "�����p";
	char texto[] = "�p��gZ";

	a = -5784;
	b = 278;
	c = -2185;
	d = 372;
	e = -3621;
	f = 514;
	
	if (c < d) {
		cout << c << " es menor que " << d << endl;
	}
	else {
		cout << c << " es mayor o igual que " << d << endl;
	}
	
	//Corrige el programa para que el mensaje de salida que se muestra sea correcto (sin modificar nada entre las l�neas 32 y 36).

	system("pause");

	return 0;
}