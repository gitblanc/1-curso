package uo.mp.battleship.game;

public class TurnSelector {

	boolean turn;
	public TurnSelector() {
		this.turn = true;
		
	}
	
	public int next() {
		if(this.turn) {
			this.turn = !turn;
			return 1;
		}
		else {
			this.turn = !turn;
			return 0;
		}
	}
}

