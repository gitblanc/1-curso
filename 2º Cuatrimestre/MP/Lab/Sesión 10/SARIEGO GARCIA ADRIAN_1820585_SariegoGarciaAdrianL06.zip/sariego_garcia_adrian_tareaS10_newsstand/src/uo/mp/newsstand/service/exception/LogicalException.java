/**
 * 
 */
package uo.mp.newsstand.service.exception;

/**
 * @author adrian
 *
 */
@SuppressWarnings("serial")
public class LogicalException extends Exception {
	public LogicalException() {
	}
	
	public LogicalException(String msg) {
		super(msg);
	}
}
