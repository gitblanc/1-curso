/**
 * 
 */
package uo.mp.transaction.model;

/**
 * @author blanc
 *
 */
public enum Client {
	Normal, Premium
}
