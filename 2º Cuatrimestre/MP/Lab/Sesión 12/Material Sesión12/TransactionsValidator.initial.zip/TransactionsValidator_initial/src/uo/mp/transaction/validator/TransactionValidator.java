package uo.mp.transaction.validator;

import java.util.List;

import uo.mp.transaction.model.Transaction;

public class TransactionValidator {

	public void add(List<Transaction> trxs) {
		// TODO 
	}

	public void validate() {
		// TODO 
	}

	public List<Transaction> getInvalidTransactions() {
		// TODO 
		return null;
	}

	public List<Transaction> getValidTransactions() {
		// TODO 
		return null;
	}

}
