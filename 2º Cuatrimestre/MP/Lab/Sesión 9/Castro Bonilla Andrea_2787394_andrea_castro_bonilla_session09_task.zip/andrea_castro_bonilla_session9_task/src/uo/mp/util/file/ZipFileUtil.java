package uo.mp.util.file;



import java.util.List;

import uo.mp.exception.NotYetImplementedException;

/**
 * A utility class to read/write text lines 
 * from/to a compressed text file (.txt.gz) 
 */
public class ZipFileUtil {

	public List<String> readLines(String inFileName) {
		throw new NotYetImplementedException();
	}

	public void writeLines(String outZippedFileName, List<String> lines) {
		throw new NotYetImplementedException();
	}

}
