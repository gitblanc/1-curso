package uo.mp.newsstand.service.parsers;

import java.util.List;

import uo.mp.exception.NotYetImplementedException;
import uo.mp.newsstand.domain.Publication;

public class PublicationParser {

	public List<Publication> parse(List<String> lines) {
		throw new NotYetImplementedException();
	}

}
