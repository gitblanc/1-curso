package uo.mp.exception;

public class NotYetImplementedException extends RuntimeException {
	private static final long serialVersionUID = 1L;

}
