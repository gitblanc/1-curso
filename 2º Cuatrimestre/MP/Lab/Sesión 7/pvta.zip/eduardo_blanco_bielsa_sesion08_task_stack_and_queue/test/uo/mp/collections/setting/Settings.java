package uo.mp.collections.setting;

public class Settings {

	public static ListFactory factory;

}
