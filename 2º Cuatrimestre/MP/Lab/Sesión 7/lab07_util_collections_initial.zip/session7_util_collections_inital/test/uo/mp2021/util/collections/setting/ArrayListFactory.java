package uo.mp2021.util.collections.setting;

import uo.mp2021.util.collections.List;
import uo.mp2021.util.collections.impl.ArrayList;

public class ArrayListFactory implements ListFactory {

	@Override
	public List newList() {
		return new ArrayList();
	}

}
