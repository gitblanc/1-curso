package uo.mp2021.util.collections.setting;


import uo.mp2021.util.collections.List;
import uo.mp2021.util.collections.impl.LinkedList;

public class LinkedListFactory implements ListFactory {

	@Override
	public List newList() {
		return new LinkedList();
	}

}
