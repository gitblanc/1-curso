package uo.mp2021.util.collections.setting;

import uo.mp2021.util.collections.List;

public interface ListFactory {

	List newList();

}
