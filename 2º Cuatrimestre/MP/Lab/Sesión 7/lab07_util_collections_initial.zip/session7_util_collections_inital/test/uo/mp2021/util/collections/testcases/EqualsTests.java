package uo.mp2021.util.collections.testcases;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import uo.mp2021.util.collections.List;
import uo.mp2021.util.collections.setting.Settings;

public class EqualsTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
