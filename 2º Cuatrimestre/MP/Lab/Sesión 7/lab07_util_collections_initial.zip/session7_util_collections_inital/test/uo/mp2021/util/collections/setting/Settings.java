package uo.mp2021.util.collections.setting;

public class Settings {

	public static ListFactory factory;

}
