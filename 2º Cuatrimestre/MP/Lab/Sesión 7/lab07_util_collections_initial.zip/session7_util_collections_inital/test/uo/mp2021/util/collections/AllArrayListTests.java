package uo.mp2021.util.collections;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import uo.mp2021.util.collections.setting.ArrayListFactory;
import uo.mp2021.util.collections.setting.Settings;
import uo.mp2021.util.collections.testcases.AddInPositionTests;
import uo.mp2021.util.collections.testcases.AddLastTests;
import uo.mp2021.util.collections.testcases.ClearTests;
import uo.mp2021.util.collections.testcases.ContainsTests;
import uo.mp2021.util.collections.testcases.EqualsTests;
import uo.mp2021.util.collections.testcases.GetTests;
import uo.mp2021.util.collections.testcases.HashCodeTests;
import uo.mp2021.util.collections.testcases.IndexOfTests;
import uo.mp2021.util.collections.testcases.IsEmptyTests;
import uo.mp2021.util.collections.testcases.RemoveFromPositionTests;
import uo.mp2021.util.collections.testcases.RemoveObjectTests;
import uo.mp2021.util.collections.testcases.SetTests;
import uo.mp2021.util.collections.testcases.SizeTests;
import uo.mp2021.util.collections.testcases.ToStringTests;

@RunWith(Suite.class)
@SuiteClasses({ AddInPositionTests.class, AddLastTests.class, ClearTests.class,
		ContainsTests.class, EqualsTests.class, GetTests.class,
		HashCodeTests.class, IndexOfTests.class, IsEmptyTests.class,
		RemoveFromPositionTests.class, RemoveObjectTests.class, SetTests.class,
		SizeTests.class, ToStringTests.class })
public class AllArrayListTests {
	
	@BeforeClass
	public static void setUp() {
		Settings.factory = new ArrayListFactory();
	}

}
