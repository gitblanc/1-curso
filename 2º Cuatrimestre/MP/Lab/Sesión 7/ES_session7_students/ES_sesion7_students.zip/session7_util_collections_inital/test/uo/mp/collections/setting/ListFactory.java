package uo.mp.collections.setting;

import uo.mp.collections.List;

public interface ListFactory {

	List newList();

}
