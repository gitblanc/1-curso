package uo.mp.s5.figure.drawable;

import java.io.PrintStream;

public interface Drawable {
	/**
	 * @author blanc
	 */


	public void draw(PrintStream out);
	

}
