/**
 * 
 */
package uo.mp.s6.greenhouse.scanner;

/**
 * @author blanc
 *
 */
public interface Checkable {
	boolean check();
	int getId();
	
}
