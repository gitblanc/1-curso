package uo.mp.s6.greenhouse.humidity;

public enum WaterSystem {
	off, low, medium, high
}
