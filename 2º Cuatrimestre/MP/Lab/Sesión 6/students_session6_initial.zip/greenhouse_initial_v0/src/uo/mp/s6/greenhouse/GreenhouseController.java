package uo.mp.s6.greenhouse;

import uo.mp.s6.greenhouse.temperature.Door;
import uo.mp.s6.greenhouse.temperature.TemperatureController;
import uo.mp.s6.greenhouse.temperature.TemperatureSensor;

/**
 * <p>Title: GreenHouseController</p>
 * <p>Description: Clase que simula al invernadero.</p>
 * <p>Copyright: Copyright (c) 2020</p>
 * <p>Escuela de Ingenier�a Inform�tica</p>
 * <p>Metodolog�a de la Programaci�n</p>
 * 
 * @author Profesores de Metodolog�a de la Programaci�n
 * @version 1.0
 */
public class GreenhouseController {
	private TemperatureController tempCtrl = new TemperatureController();

	public void add(TemperatureSensor sensor) {
		tempCtrl.add( sensor );
	}

	public void add(Door door) {
		tempCtrl.add( door );
	}

	public void start() {
		while (true) {
			tempCtrl.monitor();
			
			sleep(2000);
		}
	}

	private void sleep(int millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			// Ignore it
		}
	}

}
