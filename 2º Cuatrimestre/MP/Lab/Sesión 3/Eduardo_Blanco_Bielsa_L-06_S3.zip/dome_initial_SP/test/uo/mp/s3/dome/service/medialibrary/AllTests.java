package uo.mp.s3.dome.service.medialibrary;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AddTest.class, GetItemsTest.class, ListTest.class, NumberOfItemsOwnedTest.class, SearchItemTest.class })
public class AllTests {

}
