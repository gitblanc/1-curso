package uo.mp.s3.dome.model;

import java.io.PrintStream;

import uo.mp.checks.ArgumentsCheck;

public class Dvd extends Item {
	private String director;
	private int playingTime;

	public Dvd(String theTitle, String theDirector, int playingTime) {
		super(theTitle);
		setDirector(theDirector);
		setPlayingTime(playingTime);
	}

	private void setDirector(String director) {
		ArgumentsCheck.isTrue(director != null, "Error: director nulo");
		ArgumentsCheck.isTrue (director.length() > 0, "Error: director vac�o");
		this.director = director;

	}

	public String getDirector() {
		return this.director;
	}

	public void print(PrintStream out) {
		out.println("DVD: " + getTitle() + " (" + getPlayingTime() + " mins)");
		out.println("Director: " + getDirector());
		if (getOwn()) {
			out.println("You own it");
		} else {
			out.println("You do not own it");
		}
		out.println("Comment: " + getComment());
	}

	private void setPlayingTime(int playingTime) {
		ArgumentsCheck.isTrue (playingTime > 0, "Error: playingTime negativo"); 
			this.playingTime = playingTime;
		
	}
	
	public int getPlayingTime() {
		return this.playingTime;
	}
}
