package uo.mp.s3.dome.service;

import java.io.PrintStream;
import java.util.ArrayList;

import uo.mp.checks.ArgumentsCheck;
import uo.mp.s3.dome.model.Item;

public class MediaLibrary {

	private ArrayList<Item> items = new ArrayList<Item>();

//	public MediaLibrary() {			YA NO ASIGNAR EN CONSTRUCTOR
//		this.items = new ArrayList<Item>();
//	}

	/**
	 * A�adir items a la lista (Cds o Dvds) No se permite a�adir null
	 */
	public void add(Item item) {
		ArgumentsCheck.isTrue(item != null);
		items.add(item);

	}
	
	/**
	 *@return Devuelve el n�mero de items que posee el propietario (getOwn a true)
	 */
	public int numberOfItemsOwned() {
		int cont = 0;
		for (Item item : items) {
			if (item.getOwn()) {
				cont++;
			}
		}
		return cont;
	}
	
	/**
	 * Imprime en el objeto out todos los datos de los items
	 */
	public void list(PrintStream out) {
		for (Item item : items) {
			item.print(out);
		}
	}
	
	/**
	 * Devuelve una copia de la lista de �tems
	 */
	public ArrayList<Item> getItems(){
		ArrayList<Item> aux = new ArrayList<Item>(items);//as� se hace una copia m�s r�pido
		return aux;
	}
	
	/**
	 * Busca en lista item cuyos datos coinciden con los del item recibido por par�metro
	 */
	public int searchItem(Item item) {
		for (Item it : items) {
			if(it == item) {
				return items.indexOf(item);
			}
		}
		return -1;
	}
	
	/**
	 * Imprime en el objeto out todos los responsables de los elementos que tienen propietario
	 */
	public void printResponsable(PrintStream out) {
		for (Item it : items) {
			out.print(it.getOwn());
		}
	}
	
	public void setAllOwned() {
		for (Item it : items) {
			it.setOwn(true);
		}
	}
	
}
