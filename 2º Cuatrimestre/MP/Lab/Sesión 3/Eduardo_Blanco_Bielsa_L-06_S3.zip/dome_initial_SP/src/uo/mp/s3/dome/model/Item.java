package uo.mp.s3.dome.model;

import java.io.PrintStream;

import uo.mp.checks.ArgumentsCheck;

public class Item {

	private String title;
	private boolean gotIt;
	private String comment;


	
	public Item(String title) {
		setTitle(title);
		setOwn(false);
		setComment("No comment");
	}


	protected void setTitle(String title) {
		ArgumentsCheck.isTrue (title != null, "Error: title nulo");
		ArgumentsCheck.isTrue (title.length() > 0, "Error: title vac�o");
		this.title = title;
		
	}

	public void setOwn(boolean ownIt) {
		gotIt = ownIt;
	}

	public void setComment(String comment) {
		ArgumentsCheck.isTrue (comment != null, "Error: comment nulo");
		ArgumentsCheck.isTrue (comment.length() > 0, "Error: comment vac�o");
			this.comment = comment;
		
	}

	public String getComment() {
		return comment;
	}

	public boolean getOwn() {
		return gotIt;
	}

	public String getTitle() {
		return this.title;
	}


	public void print(PrintStream out) {
		out.print("Esto es la clase item");
		
	}

}