package uo.mp.s3.dome.model;

import java.io.PrintStream;

import uo.mp.checks.ArgumentsCheck;

public class Cd extends Item  {

	private String artist;
	private int numberOfTracks;
	private int playingTime;
	
	public Cd(String theTitle, String theArtist, int tracks, int playingTime) {
		super(theTitle);
		setArtist(theArtist);
		setPlayingTime(playingTime);
		setNumberOfTracks(tracks);
		
	}

	private void setArtist(String artist) {
		ArgumentsCheck.isTrue (artist != null, "Error: artista nulo");
		ArgumentsCheck.isTrue (artist.length() > 0, "Error: artist vac�o");
			this.artist = artist;
		
	}

	private void setNumberOfTracks(int numberOfTracks) {
		ArgumentsCheck.isTrue(numberOfTracks > 0, "Error: numberOfTracks negativo"); 
			this.numberOfTracks = numberOfTracks;
		
	}

	public String getArtist() {
		return this.artist;
	}
	
	public int getNumberOfTracks() {
		return this.numberOfTracks;
	}
	
	public void print(PrintStream out) {
		out.println("CD: " + getTitle() + " (" + getPlayingTime() + " mins)");
		out.println("Artist: " + getArtist());
		out.println("Tracks: " + getNumberOfTracks());
		if (getOwn()) {
			out.println("You own it");
		} else {
			out.println("You do not own it");
		}
		out.println("Comment: " + getComment());
	}
	
	private void setPlayingTime(int playingTime) {
		ArgumentsCheck.isTrue (playingTime > 0, "Error: playingTime negativo"); 
			this.playingTime = playingTime;
		
	}
	
	public int getPlayingTime() {
		return this.playingTime;
	}
}