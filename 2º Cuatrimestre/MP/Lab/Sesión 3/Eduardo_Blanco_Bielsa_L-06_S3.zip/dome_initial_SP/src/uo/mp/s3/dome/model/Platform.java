package uo.mp.s3.dome.model;

public enum Platform {
	XBOX, PLAYSTATION, NINTENDO
}
