/**
 * 
 */
package uo.mp.s3.dome.model;

import java.io.PrintStream;

import uo.mp.checks.ArgumentsCheck;

/**
 * @author blanc
 *
 */
public class VideoGame extends Item {

    private Platform platform;
	private String author;
	private int numberOfPlayers;
	
	
	public VideoGame(String title, String author, int numberOfPlayers, Platform platform) {
		super(title);
		setAuthor(author);
		setNumberOfPlayers(numberOfPlayers);
		ArgumentsCheck.isTrue(platform != null, "Error: platform nulo");
		this.platform = platform;
	}

	private void setAuthor(String author) {
		ArgumentsCheck.isTrue(author != null, "Error: author nulo");
		ArgumentsCheck.isTrue(author.length() > 0, "Error: author vac�o");
		this.author = author;
	}


	private void setNumberOfPlayers(int numberOfPlayers) {
		ArgumentsCheck.isTrue(numberOfPlayers > 0, "Error: numberOfPlayers negativo");
		this.numberOfPlayers = numberOfPlayers;
	}


	public String getAuthor() {
		return author;
	}


	public int getNumberOfPlayers() {
		return numberOfPlayers;
	}
	
	public Platform getPlatform() {
		return this.platform;
	}
	
	public void print(PrintStream out) {
		out.println("VideoGame: " + getTitle());
		out.println("Author: " + getAuthor());
		out.println("Jugadores: " + getNumberOfPlayers());
		out.println("Plataforma: " + getPlatform().toString());
		if (getOwn()) {
			out.println("You own it");
		} else {
			out.println("You do not own it");
		}
		out.println("Comment: " + getComment());
	}
}
