/**
 * 
 */
package uo.mp.s3.social_media.model;

import java.io.PrintStream;

import uo.mp.checks.ArgumentsCheck;

/**
 * @author blanc
 *
 */
public class Message extends Post {
	private String message;

	/**
	 * Constructor
	 * 
	 * @param message
	 */
	public Message(String user, String message) {
		super(user);
		setMessage(message);
	}

	private void setMessage(String message) {
		ArgumentsCheck.isTrue(message != null, "Error: par�metro nulo");
		ArgumentsCheck.isTrue(message.length() > 0, "Error: cadena vac�a");
		this.message = message;
		
	}

	public String getMessage() {
		return message;
	}

	public void print(PrintStream out) {
		out.print("Message user: " + this.getUser() + "\t msg: " + this.getMessage() + "\t Likes: " + this.getLikes()
				+ "\t Comments: " + this.getComment());
		out.println();
	}

}
