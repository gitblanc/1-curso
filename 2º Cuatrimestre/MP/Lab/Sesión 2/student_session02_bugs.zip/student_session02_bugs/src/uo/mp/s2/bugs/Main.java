/**
 * 
 */
package uo.mp.s2.bugs;

import uo.mp.s2.bugs.ui.Application;

/**
 * @author mp-profes
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Application().run();

	}

}
