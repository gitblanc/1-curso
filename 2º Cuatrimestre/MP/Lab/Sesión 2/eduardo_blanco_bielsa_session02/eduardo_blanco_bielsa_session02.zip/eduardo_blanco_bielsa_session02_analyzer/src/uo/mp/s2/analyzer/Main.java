/**
 * 
 */
package uo.mp.s2.analyzer;

import uo.mp.s2.analyzer.ui.Application;

/**
 * @author mp-profes
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Application().run();

	}

}
