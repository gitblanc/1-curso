package uo.mp.s1.game;

import uo.mp.s1.game.ui.GameApp;

public class Main {

	public static void main(String[] args) {
		new GameApp().run();
	}

}
