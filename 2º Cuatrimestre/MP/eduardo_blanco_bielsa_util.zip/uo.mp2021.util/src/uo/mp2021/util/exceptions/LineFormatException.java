/**
 * 
 */
package uo.mp2021.util.exceptions;

/**
 * @author blanc
 *
 */
public class LineFormatException extends Exception {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int lineNumber;

   
    public LineFormatException(int ln, String message) {
        super(message);
        lineNumber = ln;
    }

    
    @Override
    public String getMessage() {
        return "LineFormatException. L�nea " + lineNumber 
                + super.getMessage();
    }

}
