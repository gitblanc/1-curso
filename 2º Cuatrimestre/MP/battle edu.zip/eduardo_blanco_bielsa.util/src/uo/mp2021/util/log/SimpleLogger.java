package uo.mp2021.util.log;

public interface SimpleLogger {
	void log(Exception ex);
}
