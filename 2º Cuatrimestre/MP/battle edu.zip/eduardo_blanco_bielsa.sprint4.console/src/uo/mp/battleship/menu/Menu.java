/**
 * 
 */
package uo.mp.battleship.menu;

/**
 * @author blanc
 *
 */
public class Menu {

}
