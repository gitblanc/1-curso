package uo.mp.newsstand.service.exception;

public class NotYetImplementedException extends RuntimeException {
	private static final long serialVersionUID = 1L;

}
