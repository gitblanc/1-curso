package uo.mp.battleship.session;

public enum GameLevel {
	SEA, OCEAN, PLANET
}
