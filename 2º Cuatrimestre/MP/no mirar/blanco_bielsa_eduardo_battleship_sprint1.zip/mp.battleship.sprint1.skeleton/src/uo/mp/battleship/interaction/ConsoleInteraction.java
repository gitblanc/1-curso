package uo.mp.battleship.interaction;

import uo.mp.battleship.board.Board;

public class ConsoleInteraction {

	public static void showGameStatus(Board left, Board right, boolean debugMode) {
			
	}	
}