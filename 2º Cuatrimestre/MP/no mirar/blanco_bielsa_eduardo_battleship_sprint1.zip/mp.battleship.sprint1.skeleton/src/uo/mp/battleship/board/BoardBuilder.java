package uo.mp.battleship.board;

public class BoardBuilder {

	public BoardBuilder of(int size) {
		return this;
	}

	public int[][] build() {
		return null;
	}
}