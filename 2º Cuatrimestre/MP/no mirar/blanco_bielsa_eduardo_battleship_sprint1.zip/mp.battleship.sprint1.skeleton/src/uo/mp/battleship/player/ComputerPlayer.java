package uo.mp.battleship.player;

import uo.mp.battleship.board.Board;
import uo.mp.battleship.board.Coordinate;

public class ComputerPlayer {


	public ComputerPlayer(String name) {
	}

	public String getName() {
		return null;
	}

	public void setMyShips(Board board) {
		
	}

	public void setOpponentShips(Board board) {
		
	}

	public boolean shootAt(Coordinate position) {
		return false;
	}

	public Board getMySihps() {
		return null;
	}

	public boolean hasWon() {
		return false;
	}

	public Board getOpponentShips() {
		return null;
	}

	public Coordinate makeChoice() {

		return null;
	}

}
