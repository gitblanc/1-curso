package uo.mp.battleship.game;

public class TurnSelector {

	public TurnSelector() {
	}
	
	public int next() {
		return -1;
	}
}

