package uo.mp.battleship.game;

import uo.mp.battleship.player.ComputerPlayer;
import uo.mp.battleship.player.HumanPlayer;

public class Game {

	
	public Game(HumanPlayer leftPlayer, ComputerPlayer rightPlayer) {
	}
	
	
	public Game(HumanPlayer leftPlayer, ComputerPlayer rightPlayer, int size) {
	}

	public void setDebugMode ( boolean mode ) {
	}

	public void play() {
	}


}
